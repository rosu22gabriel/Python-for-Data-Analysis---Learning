"""
Seminar 13 - Clusterizare ierarhica (totul intr-un singur fisier)

Ce face acest script, pe scurt:
1) Citeste dataset-ul de mortalitate (CSV).
2) Inlocuieste valorile lipsa (NaN):
    - numeric -> cu media coloanei
    - nenumeric -> cu valoarea modala (cel mai frecvent)
3) Construieste ierarhia cu clusterizare (linkage) folosind metoda "complete".
4) Deseneaza dendrograma (plot ierarhie).
5) Determina o partitie "optima" cu o regula tip Elbow aplicata pe distantele de aglomerare
6) Mai calculeaza si o partitie pentru k=3 clustere.
7) Salveaza partitiile intr-un fisier CSV (data_out/Partitii/csv)

Dependente:
- pandas
- numpy
- matplotlib
- scipy

"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from pandas.api.types import is_numeric_dtype
from scipy.cluster.hierarchy import linkage, dendrogram

# 1) Functii utilitare

def nan_replace_df(t: pd.DataFrame) -> None:
    """
    Inlocuieste valorile lipsa (NaN) intr-un DataFrame, "in place" (adica modifica direct t).

    Logica:
    -parcurgem fiecare coloana
    -Daca exista NaN in coloana:
        * daca este numerica -> completam NaN cu media acelei coloane
        * daca nu e numerica -> completam NaN cu valoarea modala (valoarea cea mai frecventa)

    De ce e util:
    - Algoritmii de clusterizare (si multe calcule numerice) NU functioneaza cu NaN.
    - Completarea cu media/val modala e o metoda simpla si standard pentru "imputare".
    """
    for c in t.columns:
        # t[c].isna() produce un vector True/False pe fiecare rand;
        # any(...) verifica daca exista macar un True.
        if any(t[c].isna()):
            if is_numeric_dtype(t[c]):
                # Pentru numeric: media coloanei (ignora NaN automat).
                t.fillna({c: t[c].mean()}, inplace=True)
            else:
                # Pentru nenumeric: moda (mode() poate intoarce mai multe valori; o alegem pe prima).
                t.fillna({c: t[c].mode()[0]}, inplace=True)

def salvare_ndarray(x: np.ndarray, nume_linii, nume_coloane, nume_fisier_output="out.csv") -> None:
    """
    Salveaza un numpy array ca tabel CSV, folosind pandas.

    Parametri:
    - x: matricea (ndarray) de salvat
    - nume_linii: index (etichetele randurilor)
    - nume_coloane: numele coloanelor
    - nume_fisier_output: unde salvam CSV

    Nota:
    - In proiectul original exista, dar aici nu este folosita in main
    """
    temp = pd.DataFrame(x, index=nume_linii, columns=nume_coloane)
    temp.to_csv(nume_fisier_output)


def calcul_partitie(h: np.ndarray, k: int | None = None):
    """
    Calculeaza o partitie (impartirea observatiilor in clustere) pornind de la matricea de linkage (h).

    Ce este h (linkage matrix):
    - Are forma (m, 4), unde m = n-1 (n = numar de observatii).
    - Fiecare rand i reprezinta o 'lipire' (merge) intre doua clustere:
        h[i, 0] = id cluster 1
        h[i, 1] = id cluster 2
        h[i, 2] = distanta la care s-a facut lipirea
        h[i, 3] = numarul de observatii din clusterul rezultat (nu-l folosim aici)

    Scopul functiei:
    - Daca k este None -> gaseste o partitie "optima" automat (folosind o idee de tip Elbow).
    - Daca k este dat -> returneaza partitia cu EXACT k clustere

    Returneaza:
    - k (numar clustere)
    - color_threshold (inaltimea la care "taiem" dendrograma)
    - partitie (vector de etichete "C1", "C2", ... pentru fiecare observatie)

    ----------------------------------------------------------------
    Cum decide "partitia optima" cand k=None?
    1) h[:,2] sunt distantele de aglomerare (cat de "departe" trebuie sa mergem ca sa lipim clustere).
    2) Ne uitam la diferente succesive intre distante: h[i+1, 2] - h[i, 2]
        -> unde apare "saltul" cel mai mare in distanta, inseamna ca de acolo in sus se lipesc clustere
           mult mai diferite, deci e un prag bun de taiere (heuristica Elbow).
    3) Alegem indexul j unde saltul e maxim, iar k = n - j.

    ----------------------------------------------------------------
    Cum controlam efectiv etichetele de cluster?
    - Pornim de la partitia singleton: fiecare observatie e in clusterul ei.
    - Simulam primele j lipiri (merge-uri):
        la fiecare merge i, inlocuim in vectorul c id-urile celor doua clustere unite cu id-ul nou creat.
    In SciPy, clusterele nou create au id-uri n+i.
    - La final, transformam id-urile in coduri 0...(nr_clustere-1) si puneam C1, C2, ...
    """
    m = h.shape[0] # m = n - 1
    n = m + 1      # n = numar observatii

    if k is None:
        # -----------------
        # 1) Partitia "optima" (Elbow)
        # -----------------
        # h[1:,2] - h[:m-1,2] => diferenta dintre distante consecutive.
        diferente = h[1:, 2] - h[:m - 1, 2]

        # np.argmax => pozitia celui mai mare salt
        # +1 deoarece diferente are lungimea m-1 (compara randurile 0-1, 1-2 etc)
        j = np.argmax(diferente) + 1

        # Daca am facut j merge-uri, au ramas n-j clustere.
        k = n - j
    else:
        # -----------------
        # 2) Partitia cu k clustere
        # ----------------
        # Daca vrem k clustere, trebuie sa facem exact j = n - k lipiri.
        j = n - k

    # ----------------------
    # Alegem inaltimea (pragul) la care "taiem" dendrograma.
    # Intuitie:
    # - Ca sa obtii k clustere, tai intre merge-ul j-1 si merge-ul j.
    # - Daca alegi un prag intre distantele h[j-1, 2] si h[j,2] atunci merge-uri se executa,
    # iar urmatoarele NU (deci ramai cu n-j = k clustere).
    # Pragul ales este media celor doua distante vecine:
    color_threshold = (h[j, 2], h[j - 1, 2]) / 2

    # -----------------------
    # Construim partitia efectiva
    # c porneste ca [0,1,2,...,n-1] (fiecare observatie e cluster separat)
    c = np.arange(n)

    # Simulam primele j merge-uri din h
    for i in range(j):
        k1 = h[i, 0]
        k2 = h[i, 1]

        # Inlocuim toate aparitiile clusterelor k1 si k2 cu id-ul nou (n + i)
        # Atentie: k1/k2 pot fi fie id-uri de observatii (0..n-1),
        #           fie id-uri de clustere create anterior (>= n).
        c[c == k1] = n + i
        c[c == k2] = n + i

        # c contine id-uri de clustere (nu neaparat 0..k-1).
        # pd.Categorical(c).codes transforma valorile distincte in coduri consecutive 0..k-1.
        # Apoi facem etichete "C1", "C2", ...
        partitie = ["C" + str(i + 1) for i in pd.Categorical(c).codes]

        return k, color_threshold, np.array(partitie)














